package com.example.quiz.Controllers;


import com.example.quiz.Models.Result;
import com.example.quiz.Models.User;
import com.example.quiz.Repository.UserRepository;
import com.example.quiz.Service.ResultService;
import com.example.quiz.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/user")
public class UserController {

    private final ResultService resultService;

    private  final UserService userService;

@Autowired
public  UserController(UserService userService, ResultService resultService ){
    this.userService=userService;
    this.resultService=resultService;
}


    @PostMapping("/signup")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        // Check if the user already exists
        Optional<User> existingUser = userService.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            // User already exists
            return ResponseEntity.status(409).body("User already exists"+existingUser);
        }

        // Register new user
      var res=  userService.registerUser(user);
        return ResponseEntity.ok("User registered successfully" +res);
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        Optional<User> existingUser = userService.validateUser(user);
        if (existingUser.isPresent()) {
            return ResponseEntity.ok("login successful user id is "+existingUser.get().getId()); // Return the user ID
        } else {
            return ResponseEntity.status(401).body("User not found");
        }
    }


    @GetMapping("/{id}")
    public ResponseEntity<Optional<User>> getUserById(@PathVariable Integer id) {
        Optional<User> user = userService.getUserID(id);
        return ResponseEntity.ok(user);
    }
    @GetMapping("/{id}/results")
    public ResponseEntity<List<Result>> getResultsByUser(@PathVariable Integer id) {
        List<Result> results = resultService.getResultByUserId(id);
        return ResponseEntity.ok(results);
    }


}
