package com.example.quiz.Service;

import com.example.quiz.Models.Quiz;
import com.example.quiz.Repository.QuizRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuizService {
    private QuizRepository quizRepository;

    public Quiz createQuiz(Quiz quiz) {
        return quizRepository.save(quiz);
    }

    public List<Quiz> getQuizByCategoryName(String category) {
      return quizRepository.findByCategoryName(category);
    }

    public  List<Quiz> getAllQuiz() {
    return quizRepository.findAll();
}
    public List<Quiz> getQuizzesByUser(Integer   userId) {
        return quizRepository.findByUserId(userId);
    }

    public Optional<Quiz> getQuizById(Integer id){
        return quizRepository.findById(id);
    }
    public void deleteQuiz(Integer id) {
        quizRepository.deleteById(id);
    }
}
